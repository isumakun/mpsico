-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `mpsico` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mpsico`;

DROP TABLE IF EXISTS `area`;
CREATE TABLE `area` (
  `idArea` int NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `Empresa_idEmpresa` int DEFAULT NULL,
  PRIMARY KEY (`idArea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `aspirante`;
CREATE TABLE `aspirante` (
  `idAspirante` int NOT NULL,
  `cedula` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `apellido1` varchar(255) DEFAULT NULL,
  `apellido2` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `forma` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Usuario_idUsuario` int DEFAULT NULL,
  `Empresa_idEmpresa` int DEFAULT NULL,
  PRIMARY KEY (`idAspirante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `cuestionario`;
CREATE TABLE `cuestionario` (
  `idCuestionario` int NOT NULL AUTO_INCREMENT,
  `Numero` varchar(255) DEFAULT NULL,
  `PTC` varchar(255) DEFAULT NULL,
  `BaremoPTC` varchar(255) DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `dimension`;
CREATE TABLE `dimension` (
  `idDimension` int NOT NULL AUTO_INCREMENT,
  `Valor` varchar(255) DEFAULT NULL,
  `Puntaje` int DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idDimension`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`),
  CONSTRAINT `dimension_ibfk_1` FOREIGN KEY (`Cuestionario_idCuestionario`) REFERENCES `cuestionario` (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `dominio`;
CREATE TABLE `dominio` (
  `idDominio` int NOT NULL AUTO_INCREMENT,
  `Valor` varchar(255) DEFAULT NULL,
  `Puntaje` int DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idDominio`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`),
  CONSTRAINT `dominio_ibfk_1` FOREIGN KEY (`Cuestionario_idCuestionario`) REFERENCES `cuestionario` (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `idEmpresa` int NOT NULL,
  `nit` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sector` varchar(255) DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idEmpresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `fichapersonal`;
CREATE TABLE `fichapersonal` (
  `idFichaPersonal` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `Sexo` varchar(10) DEFAULT NULL,
  `Nacimiento` date DEFAULT NULL,
  `EstadoCivil` varchar(50) DEFAULT NULL,
  `NivelEstudios` varchar(100) DEFAULT NULL,
  `Ocupacion` varchar(100) DEFAULT NULL,
  `Ciudad` varchar(100) DEFAULT NULL,
  `Departamento` varchar(100) DEFAULT NULL,
  `Estrato` int DEFAULT NULL,
  `Vivienda` varchar(50) DEFAULT NULL,
  `PersonasACargo` int DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idFichaPersonal`),
  KEY `Aspirante_idAspirante` (`Aspirante_idAspirante`),
  CONSTRAINT `fichapersonal_ibfk_1` FOREIGN KEY (`Aspirante_idAspirante`) REFERENCES `aspirante` (`idAspirante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `fichatrabajo`;
CREATE TABLE `fichatrabajo` (
  `idFichaTrabajo` int NOT NULL AUTO_INCREMENT,
  `Ciudad` varchar(100) DEFAULT NULL,
  `Departamento` varchar(100) DEFAULT NULL,
  `Tiempo` varchar(50) DEFAULT NULL,
  `Cargo` varchar(100) DEFAULT NULL,
  `TipoCargo` varchar(50) DEFAULT NULL,
  `TiempoCargo` varchar(50) DEFAULT NULL,
  `TipoContrato` varchar(50) DEFAULT NULL,
  `HorasTrabajo` int DEFAULT NULL,
  `TipoSalario` varchar(50) DEFAULT NULL,
  `Area_idArea` int DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idFichaTrabajo`),
  KEY `Area_idArea` (`Area_idArea`),
  KEY `Aspirante_idAspirante` (`Aspirante_idAspirante`),
  CONSTRAINT `fichatrabajo_ibfk_1` FOREIGN KEY (`Area_idArea`) REFERENCES `area` (`idArea`),
  CONSTRAINT `fichatrabajo_ibfk_2` FOREIGN KEY (`Aspirante_idAspirante`) REFERENCES `aspirante` (`idAspirante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `informe`;
CREATE TABLE `informe` (
  `idInforme` int NOT NULL AUTO_INCREMENT,
  `observaciones` text,
  `recomendaciones` text,
  `Usuario_idUsuario` int DEFAULT NULL,
  PRIMARY KEY (`idInforme`),
  KEY `Usuario_idUsuario` (`Usuario_idUsuario`),
  CONSTRAINT `informe_ibfk_1` FOREIGN KEY (`Usuario_idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `pregunta`;
CREATE TABLE `pregunta` (
  `idPregunta` int NOT NULL AUTO_INCREMENT,
  `numero` int DEFAULT NULL,
  `respuesta` varchar(255) DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idPregunta`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `tipo` int NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `usuario` (`idUsuario`, `usuario`, `password`, `tipo`) VALUES
(1,	'admin',	'78eefb187936fe79a894014fab56c9a3100913f6',	1);

-- 2024-09-04 12:24:17
