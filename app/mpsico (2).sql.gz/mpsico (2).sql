-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `mpsico` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mpsico`;

DROP TABLE IF EXISTS `area`;
CREATE TABLE `area` (
  `idArea` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Empresa_idEmpresa` int DEFAULT NULL,
  PRIMARY KEY (`idArea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `area` (`idArea`, `Nombre`, `Empresa_idEmpresa`) VALUES
(1,	'dasdasdf',	1);

DROP TABLE IF EXISTS `aspirante`;
CREATE TABLE `aspirante` (
  `idAspirante` int NOT NULL AUTO_INCREMENT,
  `Cedula` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Apellido1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Apellido2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Telefono` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Direccion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Forma` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Usuario_idUsuario` int DEFAULT NULL,
  `Empresa_idEmpresa` int DEFAULT NULL,
  PRIMARY KEY (`idAspirante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `aspirante` (`idAspirante`, `Cedula`, `Nombre`, `Apellido1`, `Apellido2`, `Telefono`, `Direccion`, `Email`, `Forma`, `Usuario_idUsuario`, `Empresa_idEmpresa`) VALUES
(1,	'1083560974',	'Ismael José Castro',	'Carrasquilla',	'CO158Q164171N',	'3017095303',	'Manzana B Casa 2 Urb. Privilegios',	'isunaru@gmail.com',	'1',	4,	1);

DROP TABLE IF EXISTS `cuestionario`;
CREATE TABLE `cuestionario` (
  `idCuestionario` int NOT NULL AUTO_INCREMENT,
  `Numero` varchar(255) DEFAULT NULL,
  `PTC` varchar(255) DEFAULT NULL,
  `BaremoPTC` varchar(255) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `dimension`;
CREATE TABLE `dimension` (
  `idDimension` int NOT NULL AUTO_INCREMENT,
  `Valor` varchar(255) DEFAULT NULL,
  `Puntaje` int DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idDimension`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`),
  CONSTRAINT `dimension_ibfk_1` FOREIGN KEY (`Cuestionario_idCuestionario`) REFERENCES `cuestionario` (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `dominio`;
CREATE TABLE `dominio` (
  `idDominio` int NOT NULL AUTO_INCREMENT,
  `Valor` varchar(255) DEFAULT NULL,
  `Puntaje` int DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idDominio`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`),
  CONSTRAINT `dominio_ibfk_1` FOREIGN KEY (`Cuestionario_idCuestionario`) REFERENCES `cuestionario` (`idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `idEmpresa` int NOT NULL AUTO_INCREMENT,
  `Nit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Direccion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Telefono` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Sector` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Ciudad` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`idEmpresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `empresa` (`idEmpresa`, `Nit`, `Nombre`, `Direccion`, `Telefono`, `Email`, `Sector`, `Ciudad`, `Logo`) VALUES
(1,	'1324234',	'Ismael',	'Manzana B Casa 2 Urb. Privilegios',	'3017095303',	'isunaru@gmail.com',	'afdsdfsdf',	'Santa Marta',	NULL);

DROP TABLE IF EXISTS `fichapersonal`;
CREATE TABLE `fichapersonal` (
  `idFichaPersonal` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `Sexo` varchar(10) DEFAULT NULL,
  `Nacimiento` int DEFAULT NULL,
  `EstadoCivil` varchar(50) DEFAULT NULL,
  `NivelEstudios` varchar(100) DEFAULT NULL,
  `Ocupacion` varchar(100) DEFAULT NULL,
  `Ciudad` varchar(100) DEFAULT NULL,
  `Departamento` varchar(100) DEFAULT NULL,
  `Estrato` int DEFAULT NULL,
  `Vivienda` varchar(50) DEFAULT NULL,
  `PersonasACargo` int DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idFichaPersonal`),
  KEY `Aspirante_idAspirante` (`Aspirante_idAspirante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `fichapersonal` (`idFichaPersonal`, `Nombre`, `Apellido1`, `Apellido2`, `Sexo`, `Nacimiento`, `EstadoCivil`, `NivelEstudios`, `Ocupacion`, `Ciudad`, `Departamento`, `Estrato`, `Vivienda`, `PersonasACargo`, `Aspirante_idAspirante`) VALUES
(1,	'Ismael',	'Carrasquilla',	'Castro',	'm',	1900,	'Divorciado (a)',	'Profesional incompleto',	'asdfsadf',	'Santa Marta',	'dsafsdf',	5,	'Propia',	2,	1);

DROP TABLE IF EXISTS `fichatrabajo`;
CREATE TABLE `fichatrabajo` (
  `idFichaTrabajo` int NOT NULL AUTO_INCREMENT,
  `Ciudad` varchar(100) DEFAULT NULL,
  `Departamento` varchar(100) DEFAULT NULL,
  `Tiempo` varchar(50) DEFAULT NULL,
  `Cargo` varchar(100) DEFAULT NULL,
  `TipoCargo` varchar(50) DEFAULT NULL,
  `TiempoCargo` varchar(50) DEFAULT NULL,
  `TipoContrato` varchar(50) DEFAULT NULL,
  `HorasTrabajo` int DEFAULT NULL,
  `TipoSalario` varchar(50) DEFAULT NULL,
  `Area_idArea` int DEFAULT NULL,
  `Aspirante_idAspirante` int DEFAULT NULL,
  PRIMARY KEY (`idFichaTrabajo`),
  KEY `Aspirante_idAspirante` (`Aspirante_idAspirante`),
  KEY `Area_idArea` (`Area_idArea`),
  CONSTRAINT `fichatrabajo_ibfk_3` FOREIGN KEY (`Area_idArea`) REFERENCES `area` (`idArea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `fichatrabajo` (`idFichaTrabajo`, `Ciudad`, `Departamento`, `Tiempo`, `Cargo`, `TipoCargo`, `TiempoCargo`, `TipoContrato`, `HorasTrabajo`, `TipoSalario`, `Area_idArea`, `Aspirante_idAspirante`) VALUES
(2,	'Santa Marta',	'dsfsdf',	'De 5 a 10 años',	'dfsdf',	'Profesional, analista, técnico, tecnólogo',	'Menos de un año',	'Término indefinido',	2,	'Una parte fija y otra variable',	1,	1);

DROP TABLE IF EXISTS `informe`;
CREATE TABLE `informe` (
  `idInforme` int NOT NULL AUTO_INCREMENT,
  `Observaciones` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Recomendaciones` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Usuario_idUsuario` int DEFAULT NULL,
  PRIMARY KEY (`idInforme`),
  KEY `Usuario_idUsuario` (`Usuario_idUsuario`),
  CONSTRAINT `informe_ibfk_1` FOREIGN KEY (`Usuario_idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `pregunta`;
CREATE TABLE `pregunta` (
  `idPregunta` int NOT NULL AUTO_INCREMENT,
  `Numero` int DEFAULT NULL,
  `Respuesta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Cuestionario_idCuestionario` int DEFAULT NULL,
  PRIMARY KEY (`idPregunta`),
  KEY `Cuestionario_idCuestionario` (`Cuestionario_idCuestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `prueba`;
CREATE TABLE `prueba` (
  `idPrueba` int NOT NULL AUTO_INCREMENT,
  `link` text NOT NULL,
  PRIMARY KEY (`idPrueba`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `consentimiento` int DEFAULT NULL,
  `tipo` int NOT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `idUsuario_usuario_tipo` (`idUsuario`,`usuario`,`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `usuario` (`idUsuario`, `usuario`, `password`, `consentimiento`, `tipo`) VALUES
(1,	'admin',	'78eefb187936fe79a894014fab56c9a3100913f6',	NULL,	1),
(4,	'1083560974',	'730c5c418f06ae05f4ded6e02674029ea9902fac',	NULL,	2);

-- 2024-09-06 05:32:16
